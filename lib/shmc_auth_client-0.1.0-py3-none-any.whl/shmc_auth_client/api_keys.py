"""Reusable SHMC API-key verification helpers for subprojects.

This module belongs to the lightweight client package. It prefers central
AuthRouter verification and only uses local DB verification when the full
server-side auth package is installed and explicitly configured.

=== by Sziller & GPT-5 ===
"""

from __future__ import annotations

import asyncio
import json
import os
import urllib.error
import urllib.request
from typing import Any

from fastapi import HTTPException, status

from shmc_auth_client.policies import get_projects_from_claims


DEFAULT_VERIFY_TIMEOUT_SECONDS = 5.0


def api_key_verify_url_from_env() -> str | None:
    """Return the configured central AuthRouter API-key verification URL."""
    return os.getenv("SHMC_AUTH_API_KEY_VERIFY_URL") or os.getenv("AUTH_API_KEY_VERIFY_URL")


def api_key_verify_timeout_from_env() -> float:
    """Return the configured central API-key verification timeout."""
    raw_timeout = os.getenv("SHMC_AUTH_API_KEY_VERIFY_TIMEOUT_SECONDS") or os.getenv(
        "AUTH_API_KEY_VERIFY_TIMEOUT_SECONDS"
    )
    if not raw_timeout:
        return DEFAULT_VERIFY_TIMEOUT_SECONDS
    try:
        return max(0.1, float(raw_timeout))
    except ValueError:
        return DEFAULT_VERIFY_TIMEOUT_SECONDS


def extract_api_key_from_authorization(authorization: str | None) -> str | None:
    """Extract an SHMC API key from supported Authorization schemes."""
    if not authorization:
        return None

    scheme, sep, token = authorization.partition(" ")
    if not sep or not token.strip():
        return None

    normalized_scheme = scheme.strip().lower()
    stripped_token = token.strip()
    if normalized_scheme == "apikey":
        return stripped_token
    if normalized_scheme == "bearer" and stripped_token.startswith("shmc_"):
        return stripped_token
    return None


def _post_api_key_verify(url: str, api_key: str, timeout: float) -> dict[str, Any]:
    """Call the central AuthRouter API-key verification endpoint."""
    body = json.dumps({"api_key": api_key}).encode("utf-8")
    request = urllib.request.Request(
        url=url,
        data=body,
        headers={"Content-Type": "application/json", "Accept": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        response_body = response.read().decode("utf-8")
    parsed = json.loads(response_body)
    if not isinstance(parsed, dict):
        raise RuntimeError("Auth API-key verifier returned a non-object response.")
    return parsed


async def _verify_api_key_with_central_service(api_key: str) -> dict[str, Any]:
    """Verify an API key through the configured central AuthRouter endpoint."""
    verify_url = api_key_verify_url_from_env()
    if not verify_url:
        raise RuntimeError("SHMC_AUTH_API_KEY_VERIFY_URL is not configured.")

    timeout = api_key_verify_timeout_from_env()
    try:
        response = await asyncio.to_thread(_post_api_key_verify, verify_url, api_key, timeout)
    except urllib.error.HTTPError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"API-key verification failed with HTTP {exc.code}.",
        ) from exc
    except urllib.error.URLError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"API-key verifier unavailable: {exc.reason}",
        ) from exc
    except OSError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"API-key verifier unavailable: {exc}",
        ) from exc
    except (json.JSONDecodeError, RuntimeError) as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"API-key verifier returned an invalid response: {exc}",
        ) from exc

    if not response.get("valid"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(response.get("error") or "Invalid API key."),
        )

    claims = response.get("claims")
    if not isinstance(claims, dict):
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="API-key verifier returned valid=true without claims.",
        )
    return claims


async def _verify_api_key_with_local_auth_package(api_key: str) -> dict[str, Any]:
    """Verify an API key using server-side auth modules when installed locally."""
    try:
        from shmc_auth.api_key_store import AuthAPIKeyStore, api_key_hash_secret_from_env
        from shmc_auth.db import AuthDB
    except ImportError as exc:
        raise RuntimeError("Local Auth DB API-key verification is not available.") from exc

    db_fullname = os.getenv("DB_FULLNAME_AUTH")
    db_style = os.getenv("DB_STYLE_AUTH") or "SQLite"
    if not db_fullname:
        raise RuntimeError("DB_FULLNAME_AUTH is required for local Auth DB API-key verification.")

    def verify() -> dict[str, Any]:
        store = AuthAPIKeyStore(
            AuthDB(db_fullname=db_fullname, db_style=db_style),
            hash_secret=api_key_hash_secret_from_env(),
        )
        return store.verify_key(api_key)

    try:
        return await asyncio.to_thread(verify)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(exc) or exc.__class__.__name__,
        ) from exc


async def verify_api_key_project_access(api_key: str, project_code: str) -> dict[str, Any]:
    """Verify an API key and require enabled access to one SHMC project."""
    normalized_project = str(project_code or "").strip().upper()
    if not normalized_project:
        raise ValueError("project_code must be non-empty.")

    if api_key_verify_url_from_env():
        claims = await _verify_api_key_with_central_service(api_key)
    else:
        try:
            claims = await _verify_api_key_with_local_auth_package(api_key)
        except RuntimeError as exc:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=str(exc),
            ) from exc

    projects = get_projects_from_claims(claims)
    project_code_claim = str(claims.get("project_code") or "").strip().upper()
    if normalized_project not in projects and normalized_project != project_code_claim:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"{normalized_project} project access required.",
        )

    normalized_claims = dict(claims)
    normalized_claims["credential_type"] = "api_key"
    normalized_claims["project"] = normalized_project
    normalized_claims["projects"] = sorted(projects | {project_code_claim} - {""})
    return normalized_claims
