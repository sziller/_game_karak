"""Reusable FastAPI authorization policies for SHMC JWT claims.

This module sits above ``shmc_auth_client.security``:
  - security authenticates a request and returns verified JWT claims
  - policies authorize those verified claims for common SHMC rules

Endpoint code and router code should use these dependency factories instead of
manually parsing JWTs or duplicating auth_code/project checks.

=== by Sziller & GPT-5 ===
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from fastapi import Depends, HTTPException, Request, Security, status
from fastapi.security import APIKeyHeader, OAuth2PasswordBearer

from shmc_auth_client.auth_code import AUTH_BIT_ADMIN, AUTH_BIT_REGISTERED, has_auth_bit
from shmc_auth_client.jwt_service import JWTService, jwt_error_message
from shmc_auth_client.security import get_current_claims


Claims = dict[str, Any]
PolicyDependency = Callable[..., Any]
api_key_header_scheme = APIKeyHeader(name="X-API-Key", scheme_name="apiKeyAuth", auto_error=False)
optional_browser_auth_scheme = OAuth2PasswordBearer(
    tokenUrl="auth/token",
    scheme_name="browserAuth",
    auto_error=False,
)


def get_auth_code_from_claims(claims: Claims) -> int:
    """=== Function: get_auth_code_from_claims ================================================
    Return the canonical auth_code integer from verified claims.

    === Rule ===
    auth_code is canonical. auth_level is accepted only as a compatibility fallback.

    =================================================================================== by Sziller & GPT-5 ==="""
    raw_auth_code = claims.get("auth_code")
    if raw_auth_code is None:
        raw_auth_code = claims.get("auth_level")
    try:
        return int(raw_auth_code or 0)
    except (TypeError, ValueError):
        return 0


def get_projects_from_claims(claims: Claims) -> set[str]:
    """=== Function: get_projects_from_claims ================================================
    Return normalized project codes from verified claims.

    =================================================================================== by Sziller & GPT-5 ==="""
    raw_projects = claims.get("projects") or []
    if isinstance(raw_projects, str):
        raw_projects = [raw_projects]
    try:
        return {str(project).strip().upper() for project in raw_projects if str(project).strip()}
    except TypeError:
        return set()


def _normalized_project_code(project_code: str) -> str:
    normalized = str(project_code or "").strip().upper()
    if not normalized:
        raise ValueError("project_code must be non-empty.")
    return normalized


def _validate_bit_index(bit_index: int) -> int:
    index = int(bit_index)
    if index < 0:
        raise ValueError("bit_index must be >= 0.")
    return index


def _authorization_failed(detail: str) -> None:
    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=detail)


def require_auth_bit(bit_index: int) -> PolicyDependency:
    """=== Function: require_auth_bit ==========================================================
    Build a dependency that requires one auth_code bit and returns verified claims.

    =================================================================================== by Sziller & GPT-5 ==="""
    required_bit = _validate_bit_index(bit_index)

    async def dependency(claims: Claims = Depends(get_current_claims)) -> Claims:
        auth_code = get_auth_code_from_claims(claims)
        if not has_auth_bit(auth_code, required_bit):
            _authorization_failed(f"auth_code bit {required_bit} required.")
        return claims

    return dependency


def require_any_auth_bit(*bit_indexes: int) -> PolicyDependency:
    """=== Function: require_any_auth_bit ======================================================
    Build a dependency that requires at least one auth_code bit from a set.

    =================================================================================== by Sziller & GPT-5 ==="""
    required_bits = tuple(_validate_bit_index(bit_index) for bit_index in bit_indexes)
    if not required_bits:
        raise ValueError("At least one bit index is required.")

    async def dependency(claims: Claims = Depends(get_current_claims)) -> Claims:
        auth_code = get_auth_code_from_claims(claims)
        if not any(has_auth_bit(auth_code, bit_index) for bit_index in required_bits):
            _authorization_failed(f"One of auth_code bits {required_bits} is required.")
        return claims

    return dependency


def require_project_access(project_code: str) -> PolicyDependency:
    """=== Function: require_project_access ====================================================
    Build a dependency that requires project access in verified JWT claims.

    =================================================================================== by Sziller & GPT-5 ==="""
    required_project = _normalized_project_code(project_code)

    async def dependency(claims: Claims = Depends(get_current_claims)) -> Claims:
        projects = get_projects_from_claims(claims)
        if required_project not in projects:
            _authorization_failed(f"{required_project} project access required.")
        return claims

    return dependency


def require_registered_project_access(project_code: str) -> PolicyDependency:
    """=== Function: require_registered_project_access ========================================
    Build a dependency requiring registered-user bit and project access.

    =================================================================================== by Sziller & GPT-5 ==="""
    required_project = _normalized_project_code(project_code)

    async def dependency(claims: Claims = Depends(get_current_claims)) -> Claims:
        auth_code = get_auth_code_from_claims(claims)
        projects = get_projects_from_claims(claims)
        if not has_auth_bit(auth_code, AUTH_BIT_REGISTERED):
            _authorization_failed(f"auth_code bit {AUTH_BIT_REGISTERED} required.")
        if required_project not in projects:
            _authorization_failed(f"{required_project} project access required.")
        return claims

    return dependency


def require_admin_claims() -> PolicyDependency:
    """=== Function: require_admin_claims ======================================================
    Build a dependency that requires the global admin auth_code bit.

    =================================================================================== by Sziller & GPT-5 ==="""
    return require_auth_bit(AUTH_BIT_ADMIN)


def require_project_admin_claims(project_code: str) -> PolicyDependency:
    """=== Function: require_project_admin_claims =============================================
    Build a dependency requiring admin bit and project access.

    =================================================================================== by Sziller & GPT-5 ==="""
    required_project = _normalized_project_code(project_code)

    async def dependency(claims: Claims = Depends(get_current_claims)) -> Claims:
        auth_code = get_auth_code_from_claims(claims)
        projects = get_projects_from_claims(claims)
        if not has_auth_bit(auth_code, AUTH_BIT_ADMIN):
            _authorization_failed(f"auth_code bit {AUTH_BIT_ADMIN} required.")
        if required_project not in projects:
            _authorization_failed(f"{required_project} project access required.")
        return claims

    return dependency


def _jwt_project_claims_from_authorization(authorization: str | None, project_code: str) -> Claims:
    """Verify bearer JWT claims and require registered project access."""
    if not authorization:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing Authorization bearer token.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    scheme, sep, token = authorization.partition(" ")
    if not sep or scheme.lower() != "bearer" or not token.strip():
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid Authorization bearer token.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        claims = JWTService.from_env().verify_token(token.strip())
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=jwt_error_message(exc),
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc

    claims["credential_type"] = "jwt"
    auth_code = get_auth_code_from_claims(claims)
    projects = get_projects_from_claims(claims)
    if not has_auth_bit(auth_code, AUTH_BIT_REGISTERED):
        _authorization_failed(f"auth_code bit {AUTH_BIT_REGISTERED} required.")
    if _normalized_project_code(project_code) not in projects:
        _authorization_failed(f"{_normalized_project_code(project_code)} project access required.")
    return claims


def require_registered_project_or_api_key_access(project_code: str) -> PolicyDependency:
    """=== Function: require_registered_project_or_api_key_access ===============================
    Build a dependency allowing registered JWT project access or API-key project access.

    === Accepted Credentials ===
      - Authorization: Bearer <JWT>
      - X-API-Key: <API_KEY>
      - Authorization: ApiKey <API_KEY>
      - Authorization: Bearer <API_KEY> for documented SHMC API-key compatibility

    =================================================================================== by Sziller & GPT-5 ==="""
    required_project = _normalized_project_code(project_code)

    async def dependency(
        request: Request,
        x_api_key: str | None = Security(api_key_header_scheme),
        bearer_token: str | None = Security(optional_browser_auth_scheme),
    ) -> Claims:
        from shmc_auth_client.api_keys import extract_api_key_from_authorization, verify_api_key_project_access

        authorization = request.headers.get("Authorization")
        if bearer_token:
            if bearer_token.strip().startswith("shmc_"):
                return await verify_api_key_project_access(bearer_token.strip(), required_project)
            return _jwt_project_claims_from_authorization(f"Bearer {bearer_token}", required_project)

        api_key = (x_api_key or "").strip() or extract_api_key_from_authorization(authorization)
        if api_key:
            return await verify_api_key_project_access(api_key, required_project)

        if authorization:
            return _jwt_project_claims_from_authorization(authorization, required_project)

        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing Authorization bearer token or API key.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return dependency
